output "cluster_name" {
  value = aws_eks_cluster.prod_cluster.name
}
output "db_endpoint" {
  value = aws_rds_cluster.aurora_cluster.endpoint
}
